#!/bin/bash

# File containing the list of items
file="list.txt"

sort -u $file


function yt() {
present=$(pwd)
cd /home/jay/Documents/Scripts/yt-dl
python -m venv myenv
source myenv/bin/activate
    # Check if URL is provided
    if [ -z "$1" ]; then
        echo "Usage: yt <URL>"
        return 1
    fi
    
    youtube-dl $1
    mv *.mp4 ~/Downloads
    # Use yt-dlp to download the video
    #sudo yt-dlp -f bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4] -o "/home/jay/Downloads/%(title)s.%(ext)s" "$1"
cd $present
}


# Command to run for each line
while IFS= read -r line; do
    # Replace 'echo' with the command you want to run
    echo "Processing $line"
    # Example: some_command "$line"
    yt $line
done < "$file"

